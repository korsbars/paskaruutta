import processing.core.*; 
import processing.data.*; 
import processing.event.*; 
import processing.opengl.*; 

import processing.serial.*; 
import controlP5.*; 

import java.util.HashMap; 
import java.util.ArrayList; 
import java.io.File; 
import java.io.BufferedReader; 
import java.io.PrintWriter; 
import java.io.InputStream; 
import java.io.OutputStream; 
import java.io.IOException; 

public class robotGUI extends PApplet {




ControlP5 cp5;
Serial serialPort;
 
// Side view visualization offsets
int Xoffset = 200;
int Yoffset = 550;

// Top view visualization offsets
int TXoffset = 800;
int TYoffset = 520;

final float a1 = 198; // shoulder-to-elbow "bone" length
final float a2 = 220; // elbow-to-wrist "bone" length
final float a3 = 20; //wrist to plate length

final float j0scaler = 32.0f*400.0f*76.0f/(360.0f*23.0f);
final float j1scaler = 2*(512.0f/360.0f);
final float j2scaler = 1.0f;
final float j3scaler = 1.0f;

final float j0maxCommand = 6000.0f;
final float j1maxCommand = 100.0f;

double lastControlTime = 0.0f;
float j0errorSum = 0.0f;

boolean elbowup = true; // true=elbow up, false=elbow down

// Joint local angles
float theta0 = 0.0f; //Base rotation, azimuth
float theta1 = 0.0f; //Shoulder rotation, altitude
float theta2 = 0.0f; //Elbow rotation
float theta3 = 0.0f; //Wrist rotation

// Robot joint angle setpoints
float rsTheta0 = 0.0f;
float rsTheta1 = 0.0f;
float rsTheta2 = 0.0f;
float rsTheta3 = 0.0f;

// Robot near real time joint angles
float rTheta0 = 0.0f;
float rTheta1 = 0.0f;
float rTheta2 = 0.0f;
float rTheta3 = 0.0f;

float j0kp = 400.0f;
float lastj0output = 0.0f;

float j1kp = 5.0f;
float j1ki = 0.0f;
float j1kd = 0.0f;

float j2kp = 0.0f;
float j2ki = 0.0f;
float j2kd = 0.0f;

// float j3kp = 0.0;
// float j3ki = 0.0;
// float j3kd = 0.0;

float globalToolAngle = 0.0f;
float controlPosX = 0;
float controlPosY = 500;
boolean updateKinematics = false;
boolean inverseSolution = true;
boolean j0snap = true;
boolean motorsEnabled = false;
boolean connectedToRobot = false;
int pressed = 0;
String textValue = "";

Knob j0sp;
Toggle enableMotors;
Toggle connectSerial;
Textfield j3sp;
DropdownList drop0;

public void setup() {
 
  size(1100, 650, P3D);
  background(157, 6, 50);
  fill(255);
  PFont font = createFont("arial",15);
  PFont bfont = createFont("arial",65);
  textFont(bfont);
  text("Initializing", 400, 325);
  textFont(font);
  
  cp5 = new ControlP5(this);
  
  cp5.setColorForeground(color(0,150,136));
  cp5.setColorBackground(color(180,180,180));
  cp5.setColorLabel(color(255,255,255)); 
  cp5.setColorValue(255); //Text entry color
  cp5.setColorActive(color(150,231,45));
  
  cp5.addBang("flipElbow")
     .setPosition(1000,20)
     .setSize(80,40)
     .setCaptionLabel("Flip robot elbow")
     .getCaptionLabel().align(ControlP5.CENTER, ControlP5.CENTER)
     ;   
     
  cp5.addBang("snapJ0")
     .setPosition(1000,80)
     .setSize(80,40)
     .setCaptionLabel("\nToggle robot base\n  snap to position")
     .getCaptionLabel().align(ControlP5.CENTER, ControlP5.TOP)
     ;   
     
  cp5.addBang("loadRobotTheta")
     .setPosition(1000,140)
     .setSize(80,40)
     .setCaptionLabel("\n Load axis pose\n    from robot")
     .getCaptionLabel().align(ControlP5.CENTER, ControlP5.TOP)
     ;  
     
  cp5.addBang("zeroJoints")
     .setPosition(1000,200)
     .setSize(80,40)
     .setCaptionLabel("Reset robot pose")
     .getCaptionLabel().align(ControlP5.CENTER, ControlP5.CENTER)
     ; 
     
  cp5.addBang("driveRobot")
     .setPosition(1000,260)
     .setSize(80,40)
     .setCaptionLabel("\n Drive robot\nto new pose")
     .getCaptionLabel().align(ControlP5.CENTER, ControlP5.TOP)
     ; 
     
  enableMotors = cp5.addToggle("enableMotors")
     .setPosition(1000,320)
     .setSize(80,40)
     .setLabel("Enable motors")
     ; 
     
  controlP5.Label enableMotorsLabel = enableMotors.captionLabel();
  enableMotorsLabel.style().marginTop = -28; //move upwards (relative to button size)
  enableMotorsLabel.style().marginLeft = 11; //move to the right
     
  cp5.addBang("zeroController")
     .setPosition(1000,380)
     .setSize(80,40)
     .setCaptionLabel("Zero Robot State")
     .getCaptionLabel().align(ControlP5.CENTER, ControlP5.CENTER)
     ; 
  
  cp5.addBang("refreshSerial")
     .setPosition(1000,440)
     .setSize(80,40)
     .setCaptionLabel("\n    Refresh\n serial ports")
     .getCaptionLabel().align(ControlP5.CENTER, ControlP5.TOP)
     ;    
     
  connectSerial = cp5.addToggle("connectSerial")
     .setPosition(1000,500)
     .setSize(80,40)
     .setLabel("Connect to robot")
     ; 
     
  controlP5.Label connectSerialLabel = connectSerial.captionLabel();
  connectSerialLabel.style().marginTop = -28; //move upwards (relative to button size)
  connectSerialLabel.style().marginLeft = 5; //move to the right
  
  j3sp = cp5.addTextfield("Global tool orientation")
     .setPosition(5,48)
     .setText("0")
     .setWidth(100)
     .setAutoClear(false)
     .setColorLabel(color(0,0,0))
     ;
     
  drop0 = cp5.addDropdownList("serialPortList")
     .setPosition(5, 110)
     .setSize(100,200)
     .setColorLabel(color(0,0,0))
     ;
  
  customize(drop0);
     
  j0sp = cp5.addKnob("j0sp")
    .setRange(180,-180)
    .setValue(0)
    .setPosition(TXoffset-40, TYoffset-40)
    .setRadius(40)
    .setNumberOfTickMarks(60)
    .setTickMarkLength(4)
    .snapToTickMarks(true)
    .setViewStyle(Knob.LINE)
    .setAngleRange(2*PI)
    .setStartAngle(HALF_PI)
    .setColorValueLabel(color(0,150,136))
    .setColorBackground(color(0,150,136))
    .setColorForeground(color(255,255,255));
    ;
    
    refreshSerial();
}
 
public void draw() {
  background(249,249,249);
  strokeWeight(4);
  fill(color(50,50,50));
  
  text("Robot local joint position: " + rTheta0 + ", " + rTheta1 + ", " + rTheta2 + ", " + rTheta3, 3, 14);
  text("Robot local joint setpoint: " + rsTheta0 + ", " + rsTheta1 + ", " + rsTheta2 + ", " + rsTheta3, 3, 28);
  text("New local joint setpoint: " + theta0 + ", " + theta1 + ", " + theta2 + ", " + theta3 , 3, 42);
  text("Robot side", 165, 595);
  text("Robot top", 770, 595);
 
  // Get mouse position and do inverse kinematics
  if (mouseButton == RIGHT) {
    controlPosX = mouseX-Xoffset;
    controlPosY = -mouseY+Yoffset;
    updateKinematics = true;
  }

  // Do inverse kinematics and calculate joint thetas
  if (updateKinematics) {
    get_angles(controlPosX, controlPosY);   
    updateKinematics = false;
  }
  
  if (!inverseSolution) {
    fill(0);
    text("Inverse kinematic solution not found", 400, 325);
  }
  
  if (motorsEnabled && ((millis() - lastControlTime) > 10)) {
    driveJoints();
    text("Motors and drive logic enabled", 500, 14);
  } else text("Motors and drive logic disabled", 500, 14);
  
  if (connectedToRobot) {
    text("Connected to robot", 500, 28);
  }
  
  // Get visualization coordinates and draw side view
  pushMatrix();
  rotateX(PI); // Make y axis point up 
  translate(Xoffset, -Yoffset); // Position arm side view
  fill(204);
  drawSide();
  popMatrix();
  
  // Draw top view
  pushMatrix();
  rotateX(PI); // Make y axis point up
  translate(TXoffset, -TYoffset); // Position arm top view
  fill(204);
  drawTop(); 
  popMatrix();
  
  delay(10);
}

public void driveJoints() {
  long now = millis();
  long timeChange = now - (long)lastControlTime;
  
  // #### Joint 0 controller
  // Calculate joint position error and accumulate integral error
  float j0err = rsTheta0 - rTheta0;
  
  // Apply constraints and P control
  float j0output = constrain(j0kp * j0err, -j0maxCommand, j0maxCommand);
  
  if (abs(lastj0output) < abs(j0output)) {
    j0output = j0output*0.05f + lastj0output*0.95f;
    lastj0output = j0output;
  }
  
  // #### Joint 1 controller
  float j1err = rsTheta1 - rTheta1;
  float j1output = constrain(j1kp * j1err, -j1maxCommand, j1maxCommand);
  
  // Pass controller output to robot
  println("Commanding robot: A" + (int)j0output + " B" + (int)j1output + " C0" + " D0" + "\n");
  serialPort.write("A"+ (int)j0output + " B" + (int)j1output + " C0" + " D0" + "\n");

  lastControlTime = millis();
}
 
// Given target(Px, Py) solve for theta1, theta2 with inverse kinematics
public void get_angles(float Px, float Py) {
  float c2 = 0.0f; 
  float s2 = 0.0f;
  // Fit control input to robot constraints
  if (sqrt(pow(Px, 2) + pow(Py, 2)) > (a1 + a2)) {
    float inputAngle =atan2(Py, Px);
    Px = (a1+a2-0.0001f)*cos(inputAngle);
    Py = (a1+a2-0.0001f)*sin(inputAngle);
  }
  
  // Find theta2 where c2 = cos(theta2) and s2 = sin(theta2)
  c2 = (pow(Px, 2) + pow(Py, 2) - pow(a1, 2) - pow(a2, 2))/(2*a1*a2); // is btwn -1 and 1
 
  if (elbowup == false) {
    s2 = sqrt(1 - pow(c2, 2)); // sqrt can be + or -, and each corresponds to a different orientation
  }
  else if (elbowup == true) {
    s2 = -sqrt(1 - pow(c2, 2));
  }
  
  // Solve for the angle in degrees, automatically in correct quadrant
  theta2 = degrees(atan2(s2, c2)); 
 
  // Find theta1 where c1 = cos(theta1) and s1 = sin(theta1)
  theta1 = degrees(atan2(-a2*s2*Px + (a1 + a2*c2)*Py, (a1 + a2*c2)*Px + a2*s2*Py)) - 90.0f;
  
  theta3 = - theta1 - theta2 + globalToolAngle;
  
  // Robustness
  if ((Float.isNaN(theta1)) || (Float.isNaN(theta2)) || (Float.isNaN(theta3))) {
    inverseSolution = false;
  } else {
    inverseSolution = true;  
  }
}
 
public void drawSide() {
  float joint1X = a1*cos(radians(theta1+90.0f));
  float joint1Y = a1*sin(radians(theta1+90.0f));
 
  float joint2X = a1*cos(radians(theta1+90.0f)) + a2*cos(radians(theta1+90.0f+theta2));
  float joint2Y = a1*sin(radians(theta1+90.0f)) + a2*sin(radians(theta1+90.0f+theta2));
  
  float joint3X1 = joint2X + a3*cos(radians(theta1+90.0f+theta2+theta3)) - 13*cos(radians(theta1+90.0f+theta2+theta3+90.0f));
  float joint3Y1 = joint2Y + a3*sin(radians(theta1+90.0f+theta2+theta3)) - 13*sin(radians(theta1+90.0f+theta2+theta3+90.0f));
  
  float joint3X2 = joint3X1 + 26*cos(radians(theta1+90.0f+theta2+theta3+90.0f));
  float joint3Y2 = joint3Y1 + 26*sin(radians(theta1+90.0f+theta2+theta3+90.0f));
  
  triangle(0, 0, 40, -25, -40, -25);
  line(0.0f, 0.0f, joint1X, joint1Y);
  fill(color(86,217,45)); //Bright green
  ellipse(joint1X, joint1Y, 20, 20);
  line(joint1X, joint1Y, joint2X, joint2Y);
  fill(color(237, 46, 6)); //Bright red
  ellipse(joint2X, joint2Y, 20, 20);
  line(joint3X1, joint3Y1, joint3X2, joint3Y2);
}

public void drawTop() { 
  rect(-43, -43, 86, 86, 7);

  float j1projX = a1*cos(radians(theta1+90))*cos(radians(theta0+90));
  float j1projY = a1*cos(radians(theta1+90))*sin(radians(theta0+90));
  
  line(0, 0, j1projX, j1projY);
  fill(color(86,217,45)); //Bright green
  ellipse(j1projX, j1projY, 20, 20);
  
  float j2projX = j1projX + a2*cos(radians(theta1+90+theta2))*cos(radians(theta0+90));
  float j2projY = j1projY + a2*cos(radians(theta1+90+theta2))*sin(radians(theta0+90));
  
  fill(color(237, 46, 6)); //Bright red
  line(j1projX, j1projY, j2projX, j2projY);
  ellipse(j2projX, j2projY, 20, 20);
}


public void controlEvent(ControlEvent theEvent) {
  if(theEvent.isAssignableFrom(Textfield.class)) {
    /*println("controlEvent: accessing a string from controller '"
            +theEvent.getName()+"': "
            +theEvent.getStringValue()
            );*/
  }
  
  if (theEvent.getName() == "Global tool orientation") {
    if (!Float.isNaN(PApplet.parseFloat(theEvent.getStringValue()))) {
      float toolInput = PApplet.parseFloat(theEvent.getStringValue());
      println("New tool setpoint " + toolInput);
      globalToolAngle = toolInput;
      updateKinematics = true;
    } else println("Illegal new tool setpoint, ignoring");    
  }
}

public void flipElbow() {
  println("Flipping elbow");
  elbowup = !elbowup;
  updateKinematics = true;
}

public void snapJ0() {
  println("Toggling Joing 0 snap");
  if (j0snap) j0sp.snapToTickMarks(false);
  else j0sp.snapToTickMarks(true);
  j0snap = !j0snap;
}

public void loadRobotTheta() {
  println("Loading thetas from robot");
  theta0 = rTheta0;
  theta1 = rTheta1;
  theta2 = rTheta2;
  theta3 = rTheta3;
}

public void zeroJoints() {
  println("Zeroing joint thetas");
  // Joint local angles
  theta0 = 0.0f; //Base rotation, azimuth
  theta1 = 0.0f; //Shoulder rotation, altitude
  theta2 = 0.0f; //Elbow rotation
  theta3 = 0.0f; //Wrist rotation
  controlPosX = 0;
  controlPosY = 500;
  j0sp.setValue(0);
  j3sp.setText("0");
}

public void driveRobot() {
  println("Driving robot to new setpoints");
  rsTheta0 = theta0;
  rsTheta1 = theta1;
  rsTheta2 = theta2;
  rsTheta3 = theta3;
  lastj0output = 0.0f;
}

public void enableMotors(boolean theFlag) {
  if (connectedToRobot) {
    if (theFlag) {
      println("Enabling robot motors");
      motorsEnabled = true;
      lastj0output = 0.0f;
      serialPort.write("T \n");
    } else {
      println("Disabling robot motors");
      motorsEnabled = false;
      serialPort.write("F \n");
    }
  } else {
    println("ERR: Must be connected to robot");
    enableMotors.setValue(false);
  }
}

public void refreshSerial() {
  print("Available ports: ");
  println(Serial.list());
  drop0.clear();
  for (int i=0;i<Serial.list().length;i++) {
    drop0.addItem(Serial.list()[i], i);
  }
}

public void connectSerial(boolean theFlag) {
  if (theFlag) {
    print("Connecting to ");
    println(Serial.list()[(int)drop0.getValue()]);
    serialPort = new Serial(this, Serial.list()[(int)drop0.getValue()], 9600);
    serialPort.bufferUntil('\n');
    println("Connection established");
    connectedToRobot = true;
  } else {
    println("Disconnected from robot");
    serialPort.stop();
    serialPort = null;
    connectedToRobot = false;
  }
}

public void zeroController() {
    if (connectedToRobot) {
    println("Zeroing robot axis counters");
    serialPort.write("Z \n");
  } else println("ERR: Must be connected to robot");
}

public void j0sp(int theValue) {
  //println("Setting new Joint 0 theta "+theValue);
  theta0 = theValue;
}

public void customize(DropdownList ddl) {
  ddl.setItemHeight(20);
  ddl.setBarHeight(15);
  ddl.captionLabel().set("SERIAL PORT");
  ddl.captionLabel().style().marginTop = 3;
  ddl.captionLabel().style().marginLeft = 3;
  ddl.valueLabel().style().marginTop = 3;
}

public void serialEvent(Serial serialPort) {
  String inString = serialPort.readStringUntil('\n');
  String items[] = split(inString, '\t');
  
  if (connectedToRobot) {
    if (inString.indexOf("INFO") != -1) {
      // Getting and printing robot information directly
      println(inString);
    } else if (inString.indexOf("ERR") != -1) {
      // Robot error! 
      println(inString);
    } else if (items.length == 4) {
      // Got valid axis pos information
      rTheta0 = PApplet.parseInt(items[0]) / j0scaler; 
      rTheta1 = PApplet.parseInt(trim(items[1])) / j1scaler;
      rTheta2 = PApplet.parseInt(trim(items[2])) / j2scaler;
      rTheta3 = PApplet.parseInt(trim(items[3])) / j3scaler;
    } else {
      println("Robot communication failure, force disconnect");
      serialPort.stop();
      serialPort = null;
      connectSerial.setValue(false);
      connectedToRobot = false;
    }
  }
}

  static public void main(String[] passedArgs) {
    String[] appletArgs = new String[] { "robotGUI" };
    if (passedArgs != null) {
      PApplet.main(concat(appletArgs, passedArgs));
    } else {
      PApplet.main(appletArgs);
    }
  }
}
